#include "base.h"
#include "startDisplay.h"
#pragma warning (disable:4996)

enum { 
		BLACK,      /*  0 : ��� */ 
		DARK_BLUE,    /*  1 : ��ο� �Ķ� */ 
		DARK_GREEN,    /*  2 : ��ο� �ʷ� */ 
		DARK_SKY_BLUE,  /*  3 : ��ο� �ϴ� */ 
		DARK_RED,    /*  4 : ��ο� ���� */ 
		DARK_VOILET,  /*  5 : ��ο� ���� */ 
		DARK_YELLOW,  /*  6 : ��ο� ��� */ 
		GRAY,      /*  7 : ȸ�� */ 
		DARK_GRAY,    /*  8 : ��ο� ȸ�� */ 
		BLUE,      /*  9 : �Ķ� */ 
		GREEN,      /* 10 : �ʷ� */ 
		SKY_BLUE,    /* 11 : �ϴ� */ 
		RED,      /* 12 : ���� */ 
		VOILET,      /* 13 : ���� */ 
		YELLOW,      /* 14 : ��� */ 	
		WHITE      /* 15 : �Ͼ� */ 	
}; 

char logo()
{
	int i;
	char ch;
	int flag;
	SetColor(WHITE*16);
	for(i=1;i<16;i++)
	{
		gotoxy(4,i);
		printf("                                                                          ");
		Sleep(50);
	}
	SetColor(BLUE*16);
	//ù°��
	gotoxy(8,2);
	printf("      ");//G
	
	Sleep(50);

	//��°��
	gotoxy(6,3);
	printf("  ");
	gotoxy(14,3);
	printf("  ");//G
	gotoxy(30,3);
	printf("  ");
	
	Sleep(50);

	//��°��
	gotoxy(6,4);
	printf("  ");//G
	gotoxy(20,4);
	printf("    ");
	gotoxy(30,4);
	printf("    ");
	gotoxy(36,4);
	printf("  ");
	gotoxy(44,4);
	printf("    ");

	Sleep(50);

	//��°��
	gotoxy(6,5);
	printf("  ");
	gotoxy(10,5);
	printf("      ");//G
	gotoxy(18,5);
	printf("  ");
	gotoxy(24,5);
	printf("  ");
	gotoxy(30,5);
	printf("  ");
	gotoxy(34,5);
	printf("  ");
	gotoxy(38,5);
	printf("  ");
	gotoxy(42,5);
	printf("  ");
	gotoxy(48,5);
	printf("  ");
	

	Sleep(50);

	//�ټ�°��
	gotoxy(6,6);
	printf("  ");
	gotoxy(14,6);
	printf("  ");//G
	gotoxy(18,6);
	printf("  ");
	gotoxy(24,6);
	printf("  ");
	gotoxy(30,6);
	printf("  ");
	gotoxy(34,6);
	printf("  ");
	gotoxy(38,6);
	printf("  ");
	gotoxy(42,6);
	printf("        ");
	
	Sleep(50);

	//����°��
	gotoxy(8,7);
	printf("      ");//G
	gotoxy(18,7);
	printf("  ");
	gotoxy(24,7);
	printf("    ");
	gotoxy(30,7);
	printf("  ");
	gotoxy(38,7);
	printf("  ");
	gotoxy(42,7);
	printf("  ");
	
	Sleep(50);

	//�ϰ�°��
	gotoxy(20,8);
	printf("    ");
	gotoxy(26,8);
	printf("  ");
	gotoxy(44,8);
	printf("    ");
	
	Sleep(50);
	
	//������°��
	gotoxy(34,9);
	printf("      ");

	Sleep(50);

	//��ȩ��°��
	gotoxy(32,10);
	printf("  ");
	gotoxy(40,10);
	printf("  ");
	gotoxy(58,10);
	printf("    ");

	Sleep(50);

	//����°��
	gotoxy(32,11);
	printf("  ");
	gotoxy(40,11);
	printf("  ");
	gotoxy(44,11);
	printf("  ");
	gotoxy(52,11);
	printf("  ");
	gotoxy(56,11);
	printf("  ");
	gotoxy(62,11);
	printf("  ");
	gotoxy(66,11);
	printf("  ");
	gotoxy(72,11);
	printf("  ");

	Sleep(50);

	//���ѹ�°��
	gotoxy(32,12);
	printf("  ");
	gotoxy(40,12);
	printf("  ");
	gotoxy(44,12);
	printf("  ");
	gotoxy(52,12);
	printf("  ");
	gotoxy(56,12);
	printf("        ");
	gotoxy(66,12);
	printf("  ");
	gotoxy(70,12);
	printf("  ");
	


	Sleep(50);

	//���ι�°��
	gotoxy(32,13);
	printf("  ");
	gotoxy(40,13);
	printf("  ");
	gotoxy(46,13);
	printf("  ");
	gotoxy(50,13);
	printf("  ");
	gotoxy(56,13);
	printf("  ");
	gotoxy(66,13);
	printf("  ");
	gotoxy(68,13);
	printf("  ");

	Sleep(50);

	//������°��
	gotoxy(34,14);
	printf("      ");
	gotoxy(46,14);
	printf("  ");
	gotoxy(50,14);
	printf("  ");
	gotoxy(58,14);
	printf("    ");
	gotoxy(66,14);
	printf("  ");
	
	Sleep(50);

	//���׹�°��
	gotoxy(48,15);
	printf("  ");
	gotoxy(66,15);
	printf("  ");
	
	
	Sleep(50);

	SetColor(GRAY);
	gotoxy(31,16);
	printf("GameOver Ver 0.1");
	gotoxy(24,18);
	printf("[Made By DoulTeam in Lectopia]");
	gotoxy(19,20);
	printf("[Have a good time for playing this Game!!]");
	SetColor(GRAY*16+DARK_VOILET);
	gotoxy(21,23);
	printf("[F1 : HELP, ESC : exit, ElseKey : go]");
	//gotoxy(38,24);

	printHeart();
	fflush(stdin);
	Sleep(1000);
	ch=inKey(&flag);
	
	system("cls");
	return ch;
}


void printHeart()
{
	//SetColor(RED*16);
	for(int i=0;i<2;i++)
	{
	SetColor(RED*16);
	gotoxy(60,2);printf("    ");
	gotoxy(70,2);printf("    ");
	gotoxy(58,3);printf("  ");
	gotoxy(64,3);printf("  ");
	gotoxy(68,3);printf("  ");
	gotoxy(74,3);printf("  ");
	gotoxy(58,4);printf("  ");
	gotoxy(66,4);printf("  ");
	gotoxy(74,4);printf("  ");
	gotoxy(58,5);printf("  ");
	gotoxy(74,5);printf("  ");
	gotoxy(60,6);printf("  ");
	gotoxy(72,6);printf("  ");
	gotoxy(62,7);printf("  ");
	gotoxy(70,7);printf("  ");
	gotoxy(64,8);printf("  ");
	gotoxy(68,8);printf("  ");
	gotoxy(66,9);printf("  ");

	Sleep(500);
	SetColor(WHITE*16);
	
	gotoxy(60,2);printf("    ");
	gotoxy(70,2);printf("    ");
	gotoxy(58,3);printf("  ");
	gotoxy(64,3);printf("  ");
	gotoxy(68,3);printf("  ");
	gotoxy(74,3);printf("  ");
	gotoxy(58,4);printf("  ");
	gotoxy(66,4);printf("  ");
	gotoxy(74,4);printf("  ");
	gotoxy(58,5);printf("  ");
	gotoxy(74,5);printf("  ");
	gotoxy(60,6);printf("  ");
	gotoxy(72,6);printf("  ");
	gotoxy(62,7);printf("  ");
	gotoxy(70,7);printf("  ");
	gotoxy(64,8);printf("  ");
	gotoxy(68,8);printf("  ");
	gotoxy(66,9);printf("  ");
	
	SetColor(RED*16);
	gotoxy(62,3);printf("  ");
	gotoxy(70,3);printf("  ");
	gotoxy(60,4);printf("  ");
	gotoxy(64,4);printf("  ");
	gotoxy(68,4);printf("  ");
	gotoxy(72,4);printf("  ");
	gotoxy(60,5);printf("  ");
	gotoxy(66,5);printf("  ");
	gotoxy(72,5);printf("  ");
	gotoxy(62,6);printf("  ");
	gotoxy(70,6);printf("  ");
	gotoxy(64,7);printf("  ");
	gotoxy(68,7);printf("  ");
	gotoxy(66,8);printf("  ");

	Sleep(500);
	SetColor(WHITE*16);
	gotoxy(62,3);printf("  ");
	gotoxy(70,3);printf("  ");
	gotoxy(60,4);printf("  ");
	gotoxy(64,4);printf("  ");
	gotoxy(68,4);printf("  ");
	gotoxy(72,4);printf("  ");
	gotoxy(60,5);printf("  ");
	gotoxy(66,5);printf("  ");
	gotoxy(72,5);printf("  ");
	gotoxy(62,6);printf("  ");
	gotoxy(70,6);printf("  ");
	gotoxy(64,7);printf("  ");
	gotoxy(68,7);printf("  ");
	gotoxy(66,8);printf("  ");
	}
	SetColor(RED*16);
	gotoxy(60,2);printf("    ");
	gotoxy(70,2);printf("    ");
	gotoxy(58,3);printf("  ");
	gotoxy(64,3);printf("  ");
	gotoxy(68,3);printf("  ");
	gotoxy(74,3);printf("  ");
	gotoxy(58,4);printf("  ");
	gotoxy(66,4);printf("  ");
	gotoxy(74,4);printf("  ");
	gotoxy(58,5);printf("  ");
	gotoxy(74,5);printf("  ");
	gotoxy(60,6);printf("  ");
	gotoxy(72,6);printf("  ");
	gotoxy(62,7);printf("  ");
	gotoxy(70,7);printf("  ");
	gotoxy(64,8);printf("  ");
	gotoxy(68,8);printf("  ");
	gotoxy(66,9);printf("  ");
	textcolor(7,0); 
}