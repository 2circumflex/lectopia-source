#include "base.h"
#include "mazeGame.h"

int mazeGame()
{
	removeCursor();
	BOX2 Box;
	int step=0;
	char ch;
	int keyFlag;
	int res=0,gCnt=0;//�������� ����
	int i=0;
	Box.stage[0]=0;
	loadMap(&Box,&gCnt);
	blockDisplay(&Box);
	moveDisplay(&Box,&gCnt);
	goalCheck(&Box,gCnt);

	while(1)
	{
		//MapPrint(&Box);
		ch=inKey(&keyFlag);
		switch(ch)
		{	
		case UP_ARROW: upKey(&Box);break;
		case DOWN_ARROW: downKey(&Box);break;
		case LEFT_ARROW:leftKey(&Box); break;
		case RIGHT_ARROW:rightKey(&Box);break;
		case SPACE_BAR:break;
		case ESC:break;
		}
		moveDisplay(&Box,&gCnt);
		step=goalCheck(&Box,gCnt);
		if(step>0)
		{
			res=step;
			break;
		}
		if(ch==ESC)
		{
			res=-1;
			break;
		}

	} //while
	
	return res;
}


void MapPrint(BOX2* box)
{
	int i,j;
	for(i=0; i<box->stage[1]; i++)
	{
		for(j=0; j<=box->stage[2]; j++)
		{
				gotoxy(4+(j*2),i+15);
				printf("%c",box->MAP[i][j]);
		}	
	}
}

void loadMap(BOX2 *box,int* gCnt)
{
	int i,j;
	FILE* ifp;
	ifp=fopen("C:\\data\\miro.txt","rt");
	fscanf(ifp,"%d %d",&box->stage[1], &box->stage[2]); 

	fscanf(ifp,"%c",stdin);//���ڵڿ��ִ� ���๮�� ����
	fflush(stdin);

	for(i=0; i<box->stage[1]; i++)
	{
		for(j=0; j<=box->stage[2]; j++)
		{
			fscanf(ifp,"%c",&box->MAP[i][j]);
			if(box->MAP[i][j]=='\n')
			{
				box->MAP[i][j]=NULL;
				break;
			}
			if(box->MAP[i][j]=='G')
			{
				box->goal[*gCnt][0]=i;
				box->goal[*gCnt][1]=j;
				(*gCnt)++;
			}
		}
	}
	fclose(ifp);
}

void blockDisplay(BOX2 *box)
{
	int i,j;
	for(i=0; i<box->stage[1]; i++)
	{
		for(j=0; j<=box->stage[2]; j++)
		{
			if(box->MAP[i][j]=='B')
			{
				gotoxy(4+(j*2),i+2);
				printf("%s",PPP);
			}
			else if(box->MAP[i][j]=='G')
			{
				gotoxy(4+(j*2),i+2);
				printf("��");
			}
		}	
	}
}
void moveDisplay(BOX2 *box,int* gCnt)
{
	int i,j;
	for(i=0; i<box->stage[1]; i++)
	{
		for(j=0; j<box->stage[2]; j++)
		{
			if(box->MAP[i][j]=='C')
			{
				gotoxy(4+(box->object[0]*2),2+box->object[1]);
				printf("  ");
				gotoxy(4+(j*2),2+i);
				printf("��");
				box->object[0]=j;
				box->object[1]=i;
				gotoxy(40+i,15);
			}
			
		}
	}
}

void upKey(BOX2 *box)
{
	int col,row;
	col=box->object[0];
	row=box->object[1];
	if(box->MAP[row-1][col]=='N'|| box->MAP[row-1][col]=='G')
	{
		move(box,UP,1);
	}
	else if(box->MAP[row-1][col]=='T'&&(box->MAP[row-2][col]=='N'||box->MAP[row-2][col]=='G'))
	{
		move(box,UP,2);
	}
}


void downKey(BOX2 *box)
{
	int row,col;
	col=box->object[0];
	row=box->object[1];

	if(box->MAP[row+1][col]=='N'||box->MAP[row+1][col]=='G')
	{
		move(box,DOWN,1);
	}
	else if(box->MAP[row+1][col]=='T'&&(box->MAP[row+2][col]=='N'||box->MAP[row+2][col]=='G'))
	{
		move(box,DOWN,2);
	}
}
void leftKey(BOX2 *box)
{
	int row,col;
	col=box->object[0];
	row=box->object[1];

	if(box->MAP[row][col-1]=='N'|| box->MAP[row][col-1]=='G')
	{
		move(box,LEFT,1);
	}
	else if(box->MAP[row][col-1]=='T'&&(box->MAP[row][col-2]=='N'||box->MAP[row][col-2]=='G'))
	{
		move(box,LEFT,2);
	}
}
void rightKey(BOX2 *box)
{
	int row,col;
	col=box->object[0];
	row=box->object[1];

	if(box->MAP[row][col+1]=='N'|| box->MAP[row][col+1]=='G')
	{
		move(box,RIGHT,1);
	}
	else if(box->MAP[row][col+1]=='T'&&(box->MAP[row][col+2]=='N'||box->MAP[row][col+2]=='G'))
	{
		move(box,RIGHT,2);
	}
}
void move(BOX2 *box,int direction,int caseNum)
{

	int row,col;
	col=box->object[0];
	row=box->object[1];
	int num;
	if(direction==UP||direction==LEFT)
	{
		num=-1;
	}
	else
	{
		num=+1;
	}
	if(direction==UP||direction==DOWN)
	{
		if(caseNum==1)
		{
			box->MAP[row+num][col]=box->MAP[row][col];
		}
		else
		{
			box->MAP[row+num*2][col]=box->MAP[row+num][col];
			box->MAP[row+num][col]=box->MAP[row][col];
		}
	}
	else
	{
		if(caseNum==1)
		{
			box->MAP[row][col+num]=box->MAP[row][col];
		}
		else
		{
			box->MAP[row][col+num*2]=box->MAP[row][col+num];
			box->MAP[row][col+num]=box->MAP[row][col];
		}
	}
	box->MAP[row][col]='N';
}

int goalCheck(BOX2 *box,int gCnt)
{
	int i,count=0;

	for(i=0;i<gCnt;i++)
	{
		if(box->MAP[box->goal[i][0]][box->goal[i][1]]=='C')
		{
			return i+1;
		}
	}
	return 0;
	
}